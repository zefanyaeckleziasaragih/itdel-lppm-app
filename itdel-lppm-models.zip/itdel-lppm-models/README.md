# ITDel Starter Models

## Logs

- [26-10-2025] Inisialisasi proyek

## Syntax

### Menginstall package yang diperlukan

npm install

### Melakukan Sinkronisasi Database

npm run db:sync

### Melakukan Backup Database

npm run db:backup

### Memasukkan dummy data

npx ts-node scripts/seed_all.ts
