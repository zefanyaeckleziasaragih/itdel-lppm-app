import { DataTypes } from "sequelize";
import db from "../utils/dbUtil";

const TABLE_NAME = "m_seminar";

const SeminarModel = db.define(
  TABLE_NAME,
  {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
    },
    nama_forum: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    website: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    biaya: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    tableName: TABLE_NAME,
    createdAt: "created_at",
    updatedAt: "updated_at",
    timestamps: true,
  }
);

export default SeminarModel;
