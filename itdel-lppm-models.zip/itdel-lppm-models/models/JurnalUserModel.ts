import { DataTypes } from "sequelize";
import db from "../utils/dbUtil";

const TABLE_NAME = "p_jurnal_user";

const JurnalUserModel = db.define(
  TABLE_NAME,
  {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID, //tanya
      allowNull: false,
    },
    jurnal_id: {
      type: DataTypes.UUID, //tanya
      allowNull: false,
    },
  },
  {
    tableName: TABLE_NAME,
    createdAt: "created_at",
    updatedAt: "updated_at",
    timestamps: true,
  }
);

export default JurnalUserModel;
