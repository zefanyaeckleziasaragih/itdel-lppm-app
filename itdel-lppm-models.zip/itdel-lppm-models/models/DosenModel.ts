// models/DosenModel.ts
import { DataTypes } from "sequelize";
import db from "../utils/dbUtil";

const TABLE_NAME = "m_dosen";

const DosenModel = db.define(
  TABLE_NAME,
  {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    nidn: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    prodi_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    fakultas_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    sinta_id: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    scopus_id: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
  },
  {
    tableName: TABLE_NAME,
    createdAt: "created_at",
    updatedAt: "updated_at",
    timestamps: true,
  }
);

export default DosenModel;
