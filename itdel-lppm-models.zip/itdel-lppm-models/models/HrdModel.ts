// models/HrdModel.ts
import { DataTypes } from "sequelize";
import db from "../utils/dbUtil";

const TABLE_NAME = "m_hrd";

const HrdModel = db.define(
  TABLE_NAME,
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
      allowNull: false,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    jabatan: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: TABLE_NAME,
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
  }
);

export default HrdModel;
