import { DataTypes } from "sequelize";
import db from "../utils/dbUtil";

const TABLE_NAME = "t_pendanaan_jurnal";

const PendanaanJurnalModel = db.define(
  TABLE_NAME,
  {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
    },
    jurnal_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    nominal: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    website: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    mssn_pendukung: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    biaya_publikasi: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    luaran: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    tableName: TABLE_NAME,
    createdAt: "created_at",
    updatedAt: "updated_at",
    timestamps: true,
  }
);

export default PendanaanJurnalModel;
