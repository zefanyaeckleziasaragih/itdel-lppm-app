import type { Model, ModelStatic } from "sequelize";

// ========== Master Models ==========
import HakAksesModel from "./HakAksesModel";
import DosenModel from "./DosenModel";
import HrdModel from "./HrdModel";
import LppmModel from "./LppmModel";
import NotificationsModel from "./NotificationsModel";

// ========== Jurnal Models ==========
import PendanaanJurnalModel from "./PendanaanJurnalModel";
import JurnalModel from "./JurnalModel";
import PenghargaanJurnalModel from "./PenghargaanJurnalModel";
import JurnalUserModel from "./JurnalUserModel";

// ========== Seminar / Prosiding Models ==========
import PenghargaanSeminarModel from "./PenghargaanSeminarModel";
import PendanaanSeminarModel from "./PendanaanSeminarModel";
import SeminarModel from "./SeminarModel";
import SeminarUserModel from "./SeminarUser";

// =============================
// KUMPULKAN SEMUA MODEL
// =============================
const models: ModelStatic<Model>[] = [
  HakAksesModel,
  DosenModel,
  HrdModel,
  LppmModel,
  NotificationsModel,

  // Jurnal
  PendanaanJurnalModel,
  JurnalModel,
  PenghargaanJurnalModel,
  JurnalUserModel,

  // Seminar / Prosiding
  PenghargaanSeminarModel,
  PendanaanSeminarModel,
  SeminarModel,
  SeminarUserModel,
];

// =============================
// INISIALISASI RELASI
// =============================
export const initAssociations = () => {
  for (const model of models) {
    if (
      "associate" in model &&
      typeof (model as any).associate === "function"
    ) {
      (model as any).associate();
    }
  }
};

export default models;
