import { DataTypes } from "sequelize";
import db from "../utils/dbUtil";

const TABLE_NAME = "t_penghargaan_jurnal";

const PenghargaanJurnalModel = db.define(
  TABLE_NAME,
  {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
    },

    // FK ke m_dosen.oid
    jurnal_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },

    // FK ke data_jurnal.odatajurnal_id
    tanggal_diajukan: {
      type: DataTypes.DATE,
      allowNull: false,
    },

    // --- INFORMASI PENGAJUAN & PROSES ---

    status_pengajuan: {
      type: DataTypes.TEXT,
      allowNull: true,
    },

    // nominal yang diminta dosen
    nominal_usulan: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },

    // nominal yang disetujui HRD
    nominal_disetujui: {
      type: DataTypes.INTEGER,
      allowNull: true, // null sebelum HRD memutuskan
    },

    // status alur proses
    status: {
      type: DataTypes.STRING(20),
      allowNull: false,
      defaultValue: "belum_diverifikasi", // unread | read
    },

    // timeline
    tgl_pengajuan_penghargaan: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    tgl_verifikasi_lppm: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    tgl_approve_hrd: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    tgl_cair: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: TABLE_NAME,
    createdAt: "created_at",
    updatedAt: "updated_at",
    timestamps: true,
  }
);

export default PenghargaanJurnalModel;
