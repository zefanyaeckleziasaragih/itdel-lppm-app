import { DataTypes } from "sequelize";
import db from "../utils/dbUtil";

const TABLE_NAME = "m_jurnal";

const JurnalModel = db.define(
  TABLE_NAME,
  {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
    },
    issn: {
      type: DataTypes.STRING, //tanya
      allowNull: false,
    },
    judul_paper: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    nama_jurnal: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    volume: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    nomor: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    jumlah_halaman: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    url: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    tableName: TABLE_NAME,
    createdAt: "created_at",
    updatedAt: "updated_at",
    timestamps: true,
  }
);

export default JurnalModel;
