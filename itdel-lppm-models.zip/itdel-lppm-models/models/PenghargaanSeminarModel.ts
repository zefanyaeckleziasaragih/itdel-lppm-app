import { DataTypes } from "sequelize";
import db from "../utils/dbUtil";

const TABLE_NAME = "t_penghargaan_seminar";

const PenghargaanSeminarModel = db.define(
  TABLE_NAME,
  {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
    },

    seminar_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },

    tanggal_diajukan: {
      type: DataTypes.DATE,
      allowNull: false,
    },

    status_pengajuan: {
      type: DataTypes.TEXT,
      allowNull: true,
    },

    nominal_usulan: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },

    // nominal yang disetujui HRD
    nominal_disetujui: {
      type: DataTypes.INTEGER,
      allowNull: true, // null sebelum HRD memutuskan
    },

    // status alur proses
    status: {
      type: DataTypes.STRING(20),
      allowNull: false,
      defaultValue: "belum_diverifikasi", // unread | read
    },

    // timeline
    tgl_pengajuan_penghargaan: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    tgl_verifikasi_lppm: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    tgl_approve_hrd: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    tgl_cair: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: TABLE_NAME,
    createdAt: "created_at",
    updatedAt: "updated_at",
    timestamps: true,
  }
);

export default PenghargaanSeminarModel;
