import db from "../utils/dbUtil";

// Import semua model
import DosenModel from "../models/DosenModel";
import HrdModel from "../models/HrdModel";
import LppmModel from "../models/LppmModel";
import JurnalModel from "../models/JurnalModel";
import SeminarModel from "../models/SeminarModel";
import NotificationsModel from "../models/NotificationsModel";
import PendanaanJurnalModel from "../models/PendanaanJurnalModel";
import PendanaanSeminarModel from "../models/PendanaanSeminarModel";
import PenghargaanJurnalModel from "../models/PenghargaanJurnalModel";
import PenghargaanSeminarModel from "../models/PenghargaanSeminarModel";
import JurnalUserModel from "../models/JurnalUserModel";
import SeminarUser from "../models/SeminarUser";

async function seedDB(): Promise<void> {
  try {
    await db.authenticate();
    console.log("Sedang melakukan penyemaian data...");

    const now = new Date();

    // ID contoh konsisten antar tabel
    const userDosen1 = "11111111-1111-1111-1111-111111111111";
    const userDosen2 = "22222222-2222-2222-2222-222222222222";
    const userHRD = "33333333-3333-3333-3333-333333333333";
    const userLPPM = "44444444-4444-4444-4444-444444444444";

    const jurnal1Id = "55555555-1111-1111-1111-111111111111";
    const jurnal2Id = "55555555-2222-2222-2222-222222222222";

    const seminar1Id = "66666666-1111-1111-1111-111111111111";
    const seminar2Id = "66666666-2222-2222-2222-222222222222";

    // =========================
    // 1. m_dosen
    // =========================
    await DosenModel.destroy({ where: {} });
    await DosenModel.bulkCreate([
      {
        id: "11111111-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
        user_id: userDosen1,
        nidn: "1234567890",
        prodi_id: "22222222-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
        fakultas_id: "33333333-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
        sinta_id: "SINTA-001",
        scopus_id: "SCOPUS-001",
        created_at: now,
        updated_at: now,
      },
      {
        id: "11111111-bbbb-bbbb-bbbb-bbbbbbbbbbbb",
        user_id: userDosen2,
        nidn: "0987654321",
        prodi_id: "22222222-bbbb-bbbb-bbbb-bbbbbbbbbbbb",
        fakultas_id: "33333333-bbbb-bbbb-bbbb-bbbbbbbbbbbb",
        sinta_id: "SINTA-002",
        scopus_id: "SCOPUS-002",
        created_at: now,
        updated_at: now,
      },
    ]);

    // =========================
    // 2. m_hrd
    // =========================
    await HrdModel.destroy({ where: {} });
    await HrdModel.create({
      id: "44444444-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
      user_id: userHRD,
      jabatan: "Kepala HRD",
      created_at: now,
      updated_at: now,
    });

    // =========================
    // 3. m_lppm
    // =========================
    await LppmModel.destroy({ where: {} });
    await LppmModel.create({
      id: "55555555-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
      user_id: userLPPM,
      jabatan: "Kepala LPPM",
      created_at: now,
      updated_at: now,
    });

    // =========================
    // 4. m_jurnal
    // =========================
    await JurnalModel.destroy({ where: {} });
    await JurnalModel.bulkCreate([
      {
        id: jurnal1Id,
        issn: "1234-5678",
        judul_paper:
          "Penerapan Machine Learning dalam Sistem Informasi Akademik",
        nama_jurnal: "Jurnal Teknologi Informasi",
        volume: "10",
        nomor: "1",
        jumlah_halaman: 12,
        url: "https://contoh-jurnal1.example.com",
        created_at: now,
        updated_at: now,
      },
      {
        id: jurnal2Id,
        issn: "8765-4321",
        judul_paper: "Analisis Big Data untuk Prediksi Kelulusan Mahasiswa",
        nama_jurnal: "Jurnal Sains Data",
        volume: "5",
        nomor: "2",
        jumlah_halaman: 18,
        url: "https://contoh-jurnal2.example.com",
        created_at: now,
        updated_at: now,
      },
    ]);

    // =========================
    // 5. m_seminar
    // (sesuaikan field dengan model SeminarModel.ts kamu)
    // =========================
    await SeminarModel.destroy({ where: {} });
    await SeminarModel.bulkCreate([
      {
        id: seminar1Id,
        nama_forum: "International Conference on Information Systems",
        // kalau di model tidak ada 'website' atau 'biaya', hapus saja field-nya
        website: "https://icis.example.com",
        biaya: 3000000,
        created_at: now,
        updated_at: now,
      },
      {
        id: seminar2Id,
        nama_forum: "National Seminar on Data Science",
        website: "https://semnas-ds.example.com",
        biaya: 1500000,
        created_at: now,
        updated_at: now,
      },
    ]);

    // =========================
    // 6. m_notifications
    // =========================
    await NotificationsModel.destroy({ where: {} });
    await NotificationsModel.bulkCreate([
      {
        id: 1,
        user_id: userDosen1,
        pesan: "Pengajuan pendanaan jurnal Anda sedang diproses.",
        status: "unread",
        read_at: null,
        created_at: now,
        updated_at: now,
      },
      {
        id: 2,
        user_id: userDosen2,
        pesan: "Penghargaan jurnal Anda telah disetujui HRD.",
        status: "read",
        read_at: now,
        created_at: now,
        updated_at: now,
      },
    ]);

    // =========================
    // 7. t_pendanaan_jurnal
    // =========================
    await PendanaanJurnalModel.destroy({ where: {} });
    await PendanaanJurnalModel.create({
      id: "77777777-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
      jurnal_id: jurnal1Id,
      // kalau di model 'nominal' bertipe STRING, ini boleh string; kalau INTEGER, ganti ke number
      nominal: "5000000",
      // field berikut sesuaikan dengan modelmu; hapus kalau tidak ada di model
      website: "https://publisher-jurnal1.example.com",
      mssn_pendukung: "MSSN-12345",
      biaya_publikasi: 5000000,
      luaran: "Terindeks Sinta 2",
      created_at: now,
      updated_at: now,
    });

    // =========================
    // 8. t_pendanaan_seminar
    // =========================
    await PendanaanSeminarModel.destroy({ where: {} });
    await PendanaanSeminarModel.create({
      id: "88888888-1111-1111-1111-111111111111", // <== SUDAH UUID VALID
      seminar_id: seminar1Id,
      nominal: "3000000",
      status: "pending",
      created_at: now,
      updated_at: now,
    });

    // =========================
    // 9. t_penghargaan_jurnal
    // =========================
    await PenghargaanJurnalModel.destroy({ where: {} });
    await PenghargaanJurnalModel.create({
      id: "88888888-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
      jurnal_id: jurnal1Id,
      tanggal_diajukan: new Date("2025-01-10"),
      status_pengajuan: "pengajuan_baru",
      nominal_usulan: 7000000,
      nominal_disetujui: 6000000,
      status: "belum_diverifikasi",
      tgl_pengajuan_penghargaan: new Date("2025-01-10"),
      tgl_verifikasi_lppm: new Date("2025-01-15"),
      tgl_approve_hrd: new Date("2025-01-20"),
      tgl_cair: new Date("2025-01-25"),
      created_at: now,
      updated_at: now,
    });

    // =========================
    // 10. t_penghargaan_seminar
    // =========================
    await PenghargaanSeminarModel.destroy({ where: {} });
    await PenghargaanSeminarModel.create({
      id: "99999999-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
      seminar_id: seminar1Id,
      tanggal_diajukan: new Date("2025-02-05"),
      status_pengajuan: "pengajuan_baru",
      nominal_usulan: 4000000,
      nominal_disetujui: 3500000,
      status: "belum_diverifikasi",
      tgl_pengajuan_penghargaan: new Date("2025-02-05"),
      tgl_verifikasi_lppm: new Date("2025-02-10"),
      tgl_approve_hrd: new Date("2025-02-15"),
      tgl_cair: new Date("2025-02-20"),
      created_at: now,
      updated_at: now,
    });

    // =========================
    // 11. p_jurnal_user
    // =========================
    await JurnalUserModel.destroy({ where: {} });
    await JurnalUserModel.bulkCreate([
      {
        id: "aaaaaaaa-1111-1111-1111-111111111111",
        user_id: userDosen1,
        jurnal_id: jurnal1Id,
        created_at: now,
        updated_at: now,
      },
      {
        id: "bbbbbbbb-1111-1111-1111-111111111111",
        user_id: userDosen2,
        jurnal_id: jurnal2Id,
        created_at: now,
        updated_at: now,
      },
    ]);

    // =========================
    // 12. p_seminar_user
    // =========================
    await SeminarUser.destroy({ where: {} });
    await SeminarUser.bulkCreate([
      {
        id: "cccccccc-1111-1111-1111-111111111111",
        user_id: userDosen1,
        // pastikan nama kolom di model SeminarUser sudah 'seminar_id'
        seminar_id: seminar1Id,
        created_at: now,
        updated_at: now,
      },
      {
        id: "dddddddd-1111-1111-1111-111111111111",
        user_id: userDosen2,
        seminar_id: seminar2Id,
        created_at: now,
        updated_at: now,
      },
    ]);

    console.log("Berhasil melakukan penyemaian database.");
  } catch (error) {
    console.error("Gagal melakukan penyemaian database: ", error);
  } finally {
    await db.close();
  }
}

(async () => {
  await seedDB();
})();
