// // scripts/seed_all.ts
// import db from "../utils/dbUtil";
// import { initAssociations } from "../models/_index";

// // Master
// import DosenModel from "../models/DosenModel";
// import HrdModel from "../models/HrdModel";
// import LppmModel from "../models/LppmModel";
// import HakAksesModel from "../models/HakAksesModel";
// import NotificationsModel from "../models/NotificationsModel";

// // Jurnal
// import DataJurnalModel from "../models/DataJurnalModel";
// import PengajuanPendanaanJurnalModel from "../models/PengajuanPendanaanJurnalModel";
// import PenghargaanJurnalModel from "../models/PenghargaanJurnalModel";
// import PenulisJurnalModel from "../models/PenulisJurnalModel";

// // Seminar / Prosiding
// import MakalahModel from "../models/MakalahModel";
// import PendanaanSeminarModel from "../models/PendanaanSeminarModel";
// import PenghargaanSeminarModel from "../models/PenghargaanSeminarModel";
// import PenulisProsidingModel from "../models/PenulisProsidingModel";

// // Artefak
// import ArtefakModel from "../models/ArtefakModel";

// async function seedAll() {
//   try {
//     await db.authenticate();
//     initAssociations();
//     console.log("✅ Terkoneksi ke database");

//     // =========================
//     // 1. HAPUS DATA LAMA (URUTAN FK AMAN)
//     // =========================
//     console.log("🧹 Menghapus data lama...");

//     // Child paling ujung
//     await ArtefakModel.destroy({ where: {}, truncate: true, cascade: true });
//     await NotificationsModel.destroy({
//       where: {},
//       truncate: true,
//       cascade: true,
//     });

//     await PenulisProsidingModel.destroy({
//       where: {},
//       truncate: true,
//       cascade: true,
//     });
//     await PenulisJurnalModel.destroy({
//       where: {},
//       truncate: true,
//       cascade: true,
//     });

//     await PenghargaanSeminarModel.destroy({
//       where: {},
//       truncate: true,
//       cascade: true,
//     });
//     await PenghargaanJurnalModel.destroy({
//       where: {},
//       truncate: true,
//       cascade: true,
//     });
//     await PendanaanSeminarModel.destroy({
//       where: {},
//       truncate: true,
//       cascade: true,
//     });
//     await PengajuanPendanaanJurnalModel.destroy({
//       where: {},
//       truncate: true,
//       cascade: true,
//     });

//     await MakalahModel.destroy({ where: {}, truncate: true, cascade: true });
//     await DataJurnalModel.destroy({ where: {}, truncate: true, cascade: true });

//     await HakAksesModel.destroy({ where: {}, truncate: true, cascade: true });
//     await HrdModel.destroy({ where: {}, truncate: true, cascade: true });
//     await LppmModel.destroy({ where: {}, truncate: true, cascade: true });
//     await DosenModel.destroy({ where: {}, truncate: true, cascade: true });

//     // =========================
//     // 2. INSERT DATA MASTER
//     // =========================

//     console.log("👨‍🏫 Seeding Dosen...");
//     const dosenList = await DosenModel.bulkCreate([
//       {
//         nidn: "001001",
//         nama: "Dr. Jonathan Silalahi",
//         email: "jonathan.silalahi@kampus.ac.id",
//         fakultas: "Informatika dan Teknik Elektro",
//         prodi: "Teknik Informatika",
//       },
//       {
//         nidn: "001002",
//         nama: "Ir. Maria Situmorang, M.Eng",
//         email: "maria.situmorang@kampus.ac.id",
//         fakultas: "Teknik Industri",
//         prodi: "Sistem Informasi",
//       },
//       {
//         nidn: "001003",
//         nama: "Dr. Budi Hartono",
//         email: "budi.hartono@kampus.ac.id",
//         fakultas: "Informatika dan Teknik Elektro",
//         prodi: "Teknik Elektro",
//       },
//     ] as any);

//     console.log("👥 Seeding HRD...");
//     const hrdList = await HrdModel.bulkCreate([
//       {
//         nama: "Admin HRD",
//         jabatan: "Administrator",
//       },
//       {
//         nama: "Staf HRD 1",
//         jabatan: "Staf",
//       },
//     ] as any);

//     console.log("🏛️ Seeding LPPM...");
//     const lppmList = await LppmModel.bulkCreate([
//       {
//         nama: "Kepala LPPM",
//         email: "kepala.lppm@kampus.ac.id",
//         no_telp: "081234567890",
//       },
//       {
//         nama: "Staf LPPM 1",
//         email: "staf.lppm@kampus.ac.id",
//         no_telp: "081234567891",
//       },
//     ] as any);

//     // =========================
//     // Hak Akses (mapping user -> akses)
//     // =========================
//     console.log("🔐 Seeding Hak Akses...");
//     await HakAksesModel.bulkCreate([
//       {
//         user_id: dosenList[0].get("oid"),
//         akses: "DOSEN",
//       },
//       {
//         user_id: dosenList[1].get("oid"),
//         akses: "DOSEN",
//       },
//       {
//         user_id: hrdList[0].get("oid"),
//         akses: "HRD",
//       },
//       {
//         user_id: lppmList[0].get("oid"),
//         akses: "LPPM",
//       },
//     ] as any);

//     // =========================
//     // 3. DATA JURNAL
//     // =========================

//     console.log("📚 Seeding Data Jurnal...");

//     const jurnalList = await DataJurnalModel.bulkCreate([
//       {
//         judul: "Penerapan Deep Learning untuk Klasifikasi Citra Tanaman Kopi",
//         nama_jurnal: "Jurnal Teknologi Informasi dan Sains",
//         volume: "10",
//         halaman: "1-10",
//         issn: "1234-5678",
//         link_jurnal: "https://contoh-jurnal.ac.id/artikel/deep-learning-kopi",
//         tahun: 2022,
//         index_jurnal: "SINTA 2",
//       },
//       {
//         judul: "Sistem Informasi Monitoring Penelitian Dosen Berbasis Web",
//         nama_jurnal: "Jurnal Sistem Informasi Kampus",
//         volume: "5",
//         halaman: "20-30",
//         issn: "8765-4321",
//         link_jurnal: "https://contoh-jurnal.ac.id/artikel/sim-penelitian",
//         tahun: 2021,
//         index_jurnal: "SINTA 3",
//       },
//       {
//         judul:
//           "Optimasi Jaringan Wireless di Area Kampus Menggunakan Algoritma XYZ",
//         nama_jurnal: "Jurnal Teknologi dan Rekayasa",
//         volume: "3",
//         halaman: "50-60",
//         issn: "5678-1234",
//         link_jurnal: "https://contoh-jurnal.ac.id/artikel/wireless-kampus",
//         tahun: 2020,
//         index_jurnal: "SINTA 4",
//       },
//     ] as any);

//     // Ambil PK jurnal
//     const jurnal1Id = jurnalList[0].get("odatajurnal_id");
//     const jurnal2Id = jurnalList[1].get("odatajurnal_id");
//     const jurnal3Id = jurnalList[2].get("odatajurnal_id");

//     // =========================
//     // 4. PENULIS JURNAL
//     // =========================

//     console.log("✍️ Seeding Penulis Jurnal...");

//     // Model: id (PK auto), data_jurnal_id, penulis
//     await PenulisJurnalModel.bulkCreate([
//       {
//         data_jurnal_id: jurnal1Id,
//         penulis: dosenList[0].get("nama"),
//       },
//       {
//         data_jurnal_id: jurnal1Id,
//         penulis: dosenList[1].get("nama"),
//       },
//       {
//         data_jurnal_id: jurnal2Id,
//         penulis: dosenList[1].get("nama"),
//       },
//     ] as any);

//     // =========================
//     // 5. PENGAJUAN PENDANAAN JURNAL
//     // =========================

//     console.log("💰 Seeding Pengajuan Pendanaan Jurnal...");

//     // Model: ppj_id (PK auto), oid_dosen, judul, nama_jurnal, link_jurnal, biaya, status
//     await PengajuanPendanaanJurnalModel.bulkCreate([
//       {
//         oid_dosen: dosenList[0].get("oid"),
//         judul: "Penerapan Deep Learning untuk Klasifikasi Citra Tanaman Kopi",
//         nama_jurnal: "Jurnal Teknologi Informasi dan Sains",
//         link_jurnal: "https://contoh-jurnal.ac.id/artikel/deep-learning-kopi",
//         biaya: 5000000,
//         status: "approved",
//       },
//       {
//         oid_dosen: dosenList[1].get("oid"),
//         judul: "Sistem Informasi Monitoring Penelitian Dosen Berbasis Web",
//         nama_jurnal: "Jurnal Sistem Informasi Kampus",
//         link_jurnal: "https://contoh-jurnal.ac.id/artikel/sim-penelitian",
//         biaya: 3500000,
//         status: "pending",
//       },
//     ] as any);

//     // =========================
//     // 6. PENGHARGAAN JURNAL
//     // =========================

//     console.log("🏅 Seeding Penghargaan Jurnal...");

//     // Model: oid (PK uuid), dosen_id, pendanaan_id, data_jurnal_id, alasan_pengajuan, status
//     const pendanaanJurnal = await PengajuanPendanaanJurnalModel.findAll();
//     await PenghargaanJurnalModel.bulkCreate([
//       {
//         dosen_id: dosenList[0].get("oid"),
//         pendanaan_id: pendanaanJurnal[0].get("ppj_id"),
//         data_jurnal_id: jurnal1Id,
//         alasan_pengajuan:
//           "Jurnal terindeks SINTA 2 dan berkontribusi pada bidang pertanian digital.",
//         status: "approved",
//       },
//       {
//         dosen_id: dosenList[2].get("oid"),
//         pendanaan_id: pendanaanJurnal[1].get("ppj_id"),
//         data_jurnal_id: jurnal3Id,
//         alasan_pengajuan:
//           "Penelitian relevan dengan pengembangan infrastruktur jaringan kampus.",
//         status: "pending",
//       },
//     ] as any);

//     // =========================
//     // 7. DATA MAKALAH / PROSIDING
//     // =========================

//     console.log("📄 Seeding Makalah (Prosiding)...");

//     // Model: oid (PK uuid), dosen_id, forum, judul, penyelenggara, tahun, link_prosiding
//     const makalahList = await MakalahModel.bulkCreate([
//       {
//         dosen_id: dosenList[0].get("oid"),
//         judul: "Implementasi IoT untuk Smart Farming di Daerah Toba",
//         forum: "International Conference on Smart Agriculture",
//         penyelenggara: "Universitas Contoh",
//         tahun: 2023,
//         link_prosiding:
//           "https://prosiding-contoh.ac.id/artikel/smart-farming-toba",
//       },
//       {
//         dosen_id: dosenList[1].get("oid"),
//         judul: "Penerapan Data Mining untuk Prediksi Kelulusan Mahasiswa",
//         forum: "National Conference on Data Science",
//         penyelenggara: "Asosiasi Data Sains Indonesia",
//         tahun: 2022,
//         link_prosiding:
//           "https://prosiding-contoh.ac.id/artikel/prediksi-kelulusan",
//       },
//     ] as any);

//     const makalah1Id = makalahList[0].get("oid");
//     const makalah2Id = makalahList[1].get("oid");

//     // =========================
//     // 8. PENULIS PROSIDING
//     // =========================

//     console.log("✍️ Seeding Penulis Prosiding...");

//     // Model: oid (PK auto), prosiding_id, nama_penulis (no timestamps)
//     await PenulisProsidingModel.bulkCreate([
//       {
//         prosiding_id: makalah1Id as any,
//         nama_penulis: dosenList[0].get("nama"),
//       },
//       {
//         prosiding_id: makalah1Id as any,
//         nama_penulis: dosenList[1].get("nama"),
//       },
//       {
//         prosiding_id: makalah2Id as any,
//         nama_penulis: dosenList[2].get("nama"),
//       },
//     ] as any);

//     // =========================
//     // 9. PENDANAAN SEMINAR
//     // =========================

//     console.log("💰 Seeding Pendanaan Seminar...");

//     // Model: oid (PK uuid), oid_dosen, nama_forum, judul_makalah, biaya, status
//     await PendanaanSeminarModel.bulkCreate([
//       {
//         oid_dosen: dosenList[0].get("oid"),
//         nama_forum: "International Conference on Smart Agriculture",
//         judul_makalah: "Implementasi IoT untuk Smart Farming di Daerah Toba",
//         biaya: 7000000,
//         status: "approved",
//       },
//       {
//         oid_dosen: dosenList[2].get("oid"),
//         nama_forum: "National Conference on Data Science",
//         judul_makalah:
//           "Penerapan Data Mining untuk Prediksi Kelulusan Mahasiswa",
//         biaya: 4000000,
//         status: "pending",
//       },
//     ] as any);

//     // =========================
//     // 10. PENGHARGAAN SEMINAR
//     // =========================

//     console.log("🏅 Seeding Penghargaan Seminar...");

//     // Model: oid (PK uuid), dosen_id, pendanaan_id (uuid), makalah_id (uuid), alasan_pengajuan, status
//     const pendanaanSeminar = await PendanaanSeminarModel.findAll();
//     await PenghargaanSeminarModel.bulkCreate([
//       {
//         dosen_id: dosenList[0].get("oid"),
//         pendanaan_id: pendanaanSeminar[0].get("oid"),
//         makalah_id: makalah1Id,
//         alasan_pengajuan:
//           "Mendapat Best Paper Award pada konferensi internasional.",
//         status: "approved",
//       },
//       {
//         dosen_id: dosenList[1].get("oid"),
//         pendanaan_id: pendanaanSeminar[1].get("oid"),
//         makalah_id: makalah2Id,
//         alasan_pengajuan:
//           "Makalah berkontribusi pada peningkatan mutu akademik.",
//         status: "pending",
//       },
//     ] as any);

//     // =========================
//     // 11. NOTIFIKASI
//     // =========================

//     console.log("🔔 Seeding Notifications...");

//     // Model: id (PK auto), user_id, pesan, status, read_at (optional)
//     await NotificationsModel.bulkCreate([
//       {
//         user_id: dosenList[0].get("oid"),
//         pesan: "Pengajuan pendanaan jurnal Anda sudah disetujui oleh LPPM.",
//         status: "unread",
//       },
//       {
//         user_id: dosenList[1].get("oid"),
//         pesan: "Penghargaan jurnal Anda sedang dalam proses penilaian.",
//         status: "unread",
//       },
//     ] as any);

//     // =========================
//     // 12. ARTEFAK
//     // =========================

//     console.log("📎 Seeding Artefak...");

//     // Model: id (PK auto), related_id (uuid), kategori, file_url
//     await ArtefakModel.bulkCreate([
//       {
//         related_id: dosenList[0].get("oid"),
//         kategori: "JURNAL",
//         file_url:
//           "https://storage.kampus.ac.id/artefak/jurnal1-bukti-publikasi.pdf",
//       },
//       {
//         related_id: dosenList[1].get("oid"),
//         kategori: "MAKALAH",
//         file_url:
//           "https://storage.kampus.ac.id/artefak/makalah1-sertifikat.pdf",
//       },
//     ] as any);

//     console.log("✅✅ SELESAI: Dummy data untuk semua tabel sudah disisipkan.");
//   } catch (error) {
//     console.error("❌ Error saat seeding:", error);
//   } finally {
//     await db.close();
//     console.log("🔒 Koneksi database ditutup.");
//   }
// }

// seedAll();
